# -*- coding: utf-8 -*-
from main import zxcvbn

__title__ = "pyzxcvbn"
__version__ = "0.5.0"
__author__ = "Takuro Wada"
__author_email__ = "taxpon@gmail.com"
__url__ = "https://github.com/taxpon/pyzxcvbn"
__license__ = "MIT"
